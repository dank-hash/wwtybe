<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the submitted username
    $username = $_POST['username'];

    // Save the username in a session variable
    session_start();
    $_SESSION['username'] = $username;

    // Redirect to the main page
    header('Location: main.php');
    exit;
}
?>