<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: index.html');
    exit;
}

// Database connection configuration
$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

// Create a new post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    // Create a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert the new post into the database
    $sql = "INSERT INTO posts (username, title, description) VALUES ('{$_SESSION['username']}', '$title', '$description')";
    if ($conn->query($sql) === TRUE) {
        echo "Post created successfully!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Media Website</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    <hr>
    <h2>Make a Post</h2>
    <form method="post" action="main.php">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required><br><br>
        <label for="description">Description:</label><br>
        <textarea id="description" name="description" required></textarea><br><br>
        <input type="submit" value="Post">
    </form>

    <h2>Posts</h2>
    <?php
    // Display all posts from the database
    $conn = new mysqli($servername, $username, $password, $dbname);
    $sql = "SELECT * FROM posts ORDER BY id DESC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div>";
            echo "<h3>" . $row['title'] . "</h3>";
            echo "<p>" . $row['description'] . "</p>";
            echo "<p>Posted by: " . $row['username'] . "</p>";
            echo "<p>Likes: " . $row['likes'] . "</p>";
            echo "<a href='like.php?id=" . $row['id'] . "'>Like</a>";
            echo "<hr>";
            echo "</div>";
        }
    } else {
        echo "No posts yet.";
    }

    $conn->close();
    ?>
</body>
</html>