<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    // Redirect to the login page if not logged in
    header('Location: index.html');
    exit;
}

// Get the post ID from the query string
$postId = $_GET['id'];

// Database connection configuration
$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the post exists
$sql = "SELECT * FROM posts WHERE id = $postId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Update the like count for the post
    $sql = "UPDATE posts SET likes = likes + 1 WHERE id = $postId";
    if ($conn->query($sql) === TRUE) {
        echo "Like added successfully!";
    } else {
        echo "Error updating like count: " . $conn->error;
    }
} else {
    echo "Post not found.";
}

$conn->close();
?>