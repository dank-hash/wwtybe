<?php
$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    
    $sql = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($sql);
    
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        
        if (password_verify($password, $row["password"])) {
            // Update last login timestamp and IP address
            $lastLogin = date("Y-m-d H:i:s");
            $ipAddress = $_SERVER['REMOTE_ADDR'];
            
            $updateSql = "UPDATE users SET last_login = '$lastLogin', ip_address = '$ipAddress' WHERE id = " . $row["id"];
            
            if ($conn->query($updateSql) === true) {
                // Start session and set session variables
                session_start();
                $_SESSION["username"] = $row["username"];
                $_SESSION["privileges"] = $row["privileges"]; // Set the privileges for the logged-in user
                
                header("Location: dashboard.php");
                exit();
            } else {
                echo "Error: " . $updateSql . "<br>" . $conn->error;
            }
        } else {
            echo "Invalid password";
        }
    } else {
        echo "User not found";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@400;700&family=Bangers&family=Fjalla+One&family=Honk:MORF,SHLN@16,19&family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Martian+Mono:wght@100..800&family=Prompt:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Protest+Riot&display=swap" rel="stylesheet">
    <style>
        body {
            align-items: center;
            display: block;
            text-align: center;
            font-family: "Amatic SC", sans-serif;
            font-weight: 400;
            font-style: normal;
        }

        form label {
            font-family: "Bangers", system-ui;
            font-weight: 400;
            font-style: normal;
        }
        
        input {
            font-family: "Bangers", system-ui;
            font-weight: 400;
            font-style: normal;
            font-size: 30px;
        }
    </style>
</head>
<body>
    <h1>Login</h1>
    
    <?php
    if(isset($_GET['registered']) && $_GET['registered'] == true){
        echo "Registration successful! Please login with your credentials.";
    }
    ?>
    
    <form action="login.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        
        <input type="submit" value="Login">
    </form>
</body>
</html>