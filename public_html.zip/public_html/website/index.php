<?php
session_start();

$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

// Database connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Redirect if user is already logged in
if (isset($_SESSION["username"])) {
    header("Location: dashboard.php");
    exit();
}

// Initialize error variables
$usernameError = "";
$registrationError = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    // Server-side validation
    if (empty($username) || empty($password)) {
        $registrationError = "Please fill in all fields.";
    } else {
        // Check if username exists
        $checkSql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($checkSql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $registrationError = "Username already exists.";
        } else {
            // Proceed with registration
            // ... (your registration logic here)
            
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert the new user into the database
            $insertSql = "INSERT INTO users (username, password) VALUES (?, ?)";
            $stmt = $conn->prepare($insertSql);
            $stmt->bind_param("ss", $username, $hashedPassword);
            $stmt->execute();
            $stmt->close();

            // After successful registration, redirect to login page
            header("Location: login.php?registered=true");
            exit();
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration and Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            align-items: center;
            display: block;
            text-align: center;
            font-family: "Amatic SC", sans-serif;
            font-weight: 400;
            font-style: normal;
        }

        h2 {
          font-family: "Bangers", system-ui;
          font-weight: 400;
          font-style: normal;
        }
        
        .register {
            border-style: solid;
            border-radius: 6px;
            width: 25%;
            display: inline-block;
        }
        
        form label {
            font-family: "Bangers", system-ui;
            font-weight: 400;
            font-style: normal;
            font-size: 30px;
        }
        
        form input {
            border-radius: 5px;
        }

        input {
          margin-bottom: 10px;
          font-family: "Bangers", system-ui;
          font-weight: 400;
          font-style: normal;
        }
        
        .loginbutton {
            border-radius: 5px;
        }
        
        @media only screen and (max-width: 600px) {
            .register {
                width: 50%;
            }
        }
        
    </style>
</head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Amatic+SC:wght@400;700&family=Bangers&family=Fjalla+One&family=Honk:MORF,SHLN@16,19&family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Martian+Mono:wght@100..800&family=Prompt:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Protest+Riot&display=swap" rel="stylesheet">
<body>
    <h1>Registration and Login</h1>
    
    <?php
    if(isset($_GET['registered']) && $_GET['registered'] == true){
        echo "<p>Registration successful! Please login with your credentials.</p>";
    }
    ?>
    <div class="register">   
    <h2>Register</h2>
    <form action="index.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        <span style="color: red;"><?php echo $usernameError; ?></span><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        
        <?php
        if (!empty($registrationError)) {
            echo "<p style='color: red;'>$registrationError</p>";
        }
        ?>
        
        <input type="submit" value="Register">
    </form>
    </div>
    <h2>Login</h2>
    <a href="/website/login.php"><button class="loginbutton">CLICK HERE TO LOGIN</button></a>
</body>
</html>