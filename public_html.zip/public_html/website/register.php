<?php
$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    
    // Check if username already exists
    $checkSql = "SELECT * FROM users WHERE username = '$username'";
    $checkResult = $conn->query($checkSql);
    
    if ($checkResult->num_rows > 0) {
        echo "Username already exists";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        $insertSql = "INSERT INTO users (username, password) VALUES ('$username', '$hashedPassword')";
        
        if ($conn->query($insertSql) === true) {
            header("Location: login.php?registered=true");
            exit();
        } else {
            echo "Error: " . $insertSql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>
    <h1>Registration and Login</h1>
    
    
    <h2>Register</h2>
    <form action="index.php" method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        
        <input type="submit" value="Register">
    </form>