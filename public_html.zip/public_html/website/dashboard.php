<?php
session_start();

$blacklistFile = 'blacklist.txt';
$userIP = $_SERVER['REMOTE_ADDR'];
$blacklistedIPs = file($blacklistFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (in_array($userIP, $blacklistedIPs)) {
    header('HTTP/1.1 403 Forbidden');
    exit("You are blacklisted from accessing this website. Reasons could be that your account wasn't verified, or there is unusual activity. If you're a FED, then fuck you!");
}

if (!isset($_SESSION["username"])) {
    header("Location: index.php");
    exit();
}

$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];

// Fetch user's privileges
$sql = "SELECT privileges FROM users WHERE username = '$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $privileges = $row["privileges"];
} else {
    $privileges = "Unknown";
}

// Fetch user list for administrators
$userList = [];
if ($privileges == "Admin") {
    $userSql = "SELECT username, privileges, last_login, ip_address FROM users";
    $userResult = $conn->query($userSql);

    if ($userResult->num_rows > 0) {
        while ($userRow = $userResult->fetch_assoc()) {
            $userList[] = $userRow;
        }
    }
}

// Handle user edit and delete actions
if ($privileges == "Admin" && isset($_GET['action']) && isset($_GET['username'])) {
    $action = $_GET['action'];
    $editUsername = $_GET['username'];

    if ($action === "edit") {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["saveUser"])) {
            $newPrivileges = $_POST["privileges"];
            $newLastLogin = $_POST["lastLogin"];
            $newIpAddress = $_POST["ipAddress"];

            // Update the user's information in the database
            $stmt = $conn->prepare("UPDATE users SET privileges = ?, last_login = ?, ip_address = ? WHERE username = ?");
            $stmt->bind_param("ssss", $newPrivileges, $newLastLogin, $newIpAddress, $editUsername);

            if ($stmt->execute()) {
                echo "User updated successfully.";
                header("Location: dashboard.php"); // Redirect back to the dashboard page
                exit();
            } else {
                echo "Error updating user: " . $stmt->error;
            }
        } else {
            // Display user edit form for the selected user
            $userSql = "SELECT username, privileges, last_login, ip_address FROM users WHERE username = '$editUsername'";
            $userResult = $conn->query($userSql);

            if ($userResult->num_rows > 0) {
                $userRow = $userResult->fetch_assoc();
            }
        }
    } elseif ($action === "delete") {
        // Delete the selected user from the database
        $deleteSql = "DELETE FROM users WHERE username = '$editUsername'";
        if ($conn->query($deleteSql) === TRUE) {
            echo "User deleted successfully.";
        } else {
            echo "Error deleting user: " . $conn->error;
        }
        echo "<br><a href='dashboard.php'>Go back to Dashboard</a>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
        .alert {
            font-size: 20px;
        }

        .fa-brands {
            font-size: 25px;
        }

        .refer {
            color: red;
            margin-bottom: -20px;
        }

        .editable-field {
            border: none;
            background-color: transparent;
        }
    </style>
  <script>
 
    </script>
</head>
<body>
    
    <h1>Welcome, <?php echo $username; ?>!</h1>
    <p>Your privileges: <?php echo $privileges; ?></p>
    <p class="alert">The website is still being worked on! <br>Upcoming features include a new menu with the option to schedule deliveries, fun tools, a forum to chat and view/post to the public, and a bunch of other cool things!<br><br>This entire website was coded by <i class="fa-brands fa-square-snapchat"></i>perky-werkys</p>
    
    <p class="refer">To prevent your account from being deleted or being IP from the website, please enter your Snapchat username below. If you don't have me added, then you'll be banned.</p><br>
    <form action="refer.php" method="POST">
        <label for="refer"><i class="fa-brands fa-square-snapchat"></i>: </label>
        <input type="text" id="refer" name="refer"><br>
        <input type="submit" value="Refer">
    </form>

    <?php if ($privileges == "Admin"): ?>
        <h2>User List</h2>
        <table>
            <tr>
                <th>Username</th>
                <th>Privileges</th>
                <th>Last Login</th>
                <th>IP Address</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($userList as $user): ?>
                <tr id="<?php echo $user["username"]; ?>">
                    <td><?php echo $user["username"]; ?></td>
                    <td><?php echo $user["privileges"]; ?></td>
                    <td><?php echo $user["last_login"]; ?></td>
                    <td><?php echo $user["ip_address"]; ?></td>
                    <td>
                        <a href="javascript:void(0)" onclick="editUser('<?php echo $user["username"]; ?>')">Edit</a>
                        <a href="dashboard.php?action=delete&username=<?php echo $user["username"]; ?>" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
    <a href="refers.html"><button>Snapchat Refers</button></a>
    <!-- Add your other dashboard content here -->
    
    <a href="logout.php">Logout</a>
</body>
</html>
