<?php
session_start();

if (!isset($_SESSION["username"])) {
    header("Location: index.php");
    exit();
}

if ($_POST["refer"] === null || $_POST["refer"] === "") {
    header("Location: dashboard.php");
    exit();
}

$servername = "localhost";
$username = "id20980495_walterwhite";
$password = "@c1dr0ckS";
$dbname = "id20980495_walterwhitebeat";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION["username"];
$refer = $_POST["refer"];

echo $refer . "<br>";
echo $username . "<br>" . "<p>Your submission will be reviewed within 24 hours</p>";

// Format the log entry
$logEntry = "User $username - $refer\n <br> ";

// Open the file in append mode
$file = fopen("refers.html", "a");

// Write the log entry to the file
fwrite($file, $logEntry);

// Close the file
fclose($file);

?>
<a href="dashboard.php"><button>RETURN</button></a>